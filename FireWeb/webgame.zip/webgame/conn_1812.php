<?php

$dbuser='root';
$dbpwd='123456';
$dbhost='127.0.0.1';
$db_charset='UTF8';
$dbname='db_game_account';


$conn=mysql_connect($dbhost,$dbuser,$dbpwd, 1, 131072);
if (!$conn) {
    die('db error');
}
if (!mysql_select_db($dbname)) {
    die('db error on selected db');
}
mysql_query('set names "'.$db_charset.'"');